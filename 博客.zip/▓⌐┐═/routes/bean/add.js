class add {
    constructor(regname,regpass){
        this.regname = regname;
        this.regpass = regpass;

    }
}
module.exports = add;